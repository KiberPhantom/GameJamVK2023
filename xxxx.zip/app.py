from flask import Flask, jsonify
from celery.result import AsyncResult
from tasks import create_task

app = Flask(__name__)

@app.route("/")
def index():
    task = create_task.delay([1,2,3,4,5,6,7])
    return f"Hello: {task.id}"

@app.route("/tasks/<task_id>", methods=["GET"])
def get_status(task_id):
    task_result = create_task.AsyncResult(task_id)
    print(task_result.state)
    return ' ', 200

if __name__ == '__main__':
    app.run(debug=True)
